
/**
 * Represents a book with author first and last names, a title, date of publication,
 * ISBN, and the number of pages.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Book
{
    // instance variables
    private String lastName;
    private String firstName;
    private String title;
    private String date;
    private String isbnNum;
    private int pages;

    /**
     * Constructor for objects of class Book, lastName and firstName
     * are for the author of the book.
     */
    public Book(String lastName, String firstName, String title, String date, String isbnNum, int pages)
    {
        // initialise instance variables
        this.lastName = lastName;
        this.firstName = firstName;
        this.title = title;
        this.date = date;
        this.isbnNum = isbnNum;
        setPages(pages);
    }

    /**
     * Set the number of pages of the book.
     */
    public void setPages(int pages)
    {
        // put your code here
        if(pages < 10){
            System.out.println("Number of pages must be more than 10");
        }
        else{
            this.pages = pages;
        }
    }
    
    /**
     * Returns the number of pages.
     */
    public int getPages()
    {
        return pages;
    }
    
    /**
     * Sets lastName.
     */
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    
    /**
     * Returns lastName value.
     */
    public String getLastName()
    {
        return lastName;
    }
    
    /**
     * Sets firstName.
     */
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    
    /**
     * Returns firstName.
     */
    public String getFirstName()
    {
        return firstName;
    }
    
    /**
     * Sets the title of the book.
     */
    public void setTitle(String title)
    {
        this.title = title;
    }
    
    /**
     * Returns the title of the book.
     */
    public String getTitle()
    {
        return title;
    }
    
    /**
     * Sets the date of publication.  mm/dd/yy format.
     */
    public void setDate(String date)
    {
        this.date = date;
    }
    
    /**
     * Returns the date.
     */
    public String getDate()
    {
        return date;
    }
    
    /**
     * Sets isbnNum.
     */
    public void setIsbnNum(String isbnNum)
    {
        this.isbnNum = isbnNum;
    }
    
    /**
     * Returns isbnNum.
     */
    public String getIsbnNum()
    {
        return isbnNum;
    }
}


/**
 * A class to check out the details of a book, the book is created when the InfoChecker class is created.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class InfoChecker
{
    // instance variables
    private Book book;

    /**
     * Constructor for objects of class InfoChecker.  Information can be added
     * later with this version.
     */
    public InfoChecker()
    {
        book = new Book("", "", "", "", "", 0);
    }
    
    /**
     * Constructor for objects of class InfoChecker.
     */
    public InfoChecker(String lastName, String firstName, String title, String date, String isbnNum, int pages)
    {
        // initialise instance variables
        book = new Book(lastName, firstName, title, date, isbnNum, pages);
    }

    /**
     * Sets the number of pages.
     */
    public void changePages(int pages)
    {
        book.setPages(pages);
    }
    
    /**
     * Gets the number of pages.
     */
    public int getPages()
    {
        return book.getPages();
    }
    
    /**
     * Sets the author last name.
     */
    public void changeLastName(String lastName)
    {
        book.setLastName(lastName);
    }
    
    /**
     * Gets the author last name.
     */
    public String getLastName()
    {
        return book.getLastName();
    }
    
    /**
     * Sets the author first name.
     */
    public void changeFirstName(String firstName)
    {
        book.setFirstName(firstName);
    }
    
    /**
     * Gets the author first name.
     */
    public String getFirstName()
    {
        return book.getFirstName();
    }
    
    /**
     * Sets the title.
     */
    public void changeTitle(String title)
    {
        book.setTitle(title);
    }
    
    /**
     * Gets the title.
     */
    public String getTitle()
    {
        return book.getTitle();
    }
    
    /**
     * Sets the publication date.
     */
    public void changeDate(String date)
    {
        book.setDate(date);
    }
    
    /**
     * Gets the date.
     */
    public String getDate()
    {
        return book.getDate();
    }
    
    /**
     * Sets the ISBN.
     */
    public void changeIsbn(String isbnNum)
    {
        book.setIsbnNum(isbnNum);
    }
    
    /**
     * Gets the ISBN.
     */
    public String getIsbnNum()
    {
        return book.getIsbnNum();
    }
    
    /**
     * Prints out the details of the book.
     */
    public void printInfo()
    {
        // put your code here
        if(book.getPages() == 0){
            System.out.println("Sorry, book must have at least 10 pages to print.");
            System.out.println("Set the number of pages to a valid amount.");
        }
        else if(book.getLastName() == "" || book.getFirstName() == "" || book.getTitle() == "" || book.getIsbnNum() == "" || book.getDate() == ""){
            System.out.println("Sorry, all fields must be filled out before printing.");
        }
        else{
            System.out.println("Last Name: " + book.getLastName());
            System.out.println("First Name: " + book.getFirstName());
            System.out.println("Title: " + book.getTitle());
            System.out.println("ISBN: " + book.getIsbnNum());
            System.out.println("Date Published: " + book.getDate());
            System.out.println("Number of Pages: " + book.getPages());
        }
    }
}

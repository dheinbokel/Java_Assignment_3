
/**
 * Write a description of class Tree here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tree
{
    // instance variables - replace the example below with your own
    private Triangle leaves;
    private Square trunk;

    /**
     * Constructor for objects of class Tree
     */
    public Tree()
    {
        // initialise instance variables
        leaves = new Triangle();
        trunk = new Square();
        setUp();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void setUp()
    {
         leaves.moveVertical(-40);
         leaves.changeSize(120, 120);
         leaves.makeVisible();
         
         trunk.changeSize(40);
         trunk.changeColor("yellow");
         trunk.moveVertical(100);
         trunk.moveHorizontal(-115);
         trunk.makeVisible();
    }
}
